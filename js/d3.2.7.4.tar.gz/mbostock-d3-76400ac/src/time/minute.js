d3.time.minute = function(date) {
  return new Date(~~(date / 6e4) * 6e4);
};

d3.time.minute.utc = d3.time.minute;